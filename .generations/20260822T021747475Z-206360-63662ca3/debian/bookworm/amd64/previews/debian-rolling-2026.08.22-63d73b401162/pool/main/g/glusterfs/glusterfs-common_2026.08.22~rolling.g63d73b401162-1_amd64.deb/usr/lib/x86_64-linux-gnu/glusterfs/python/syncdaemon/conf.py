#
# Copyright (c) 2016 Red Hat, Inc. <http://www.redhat.com>
# This file is part of GlusterFS.

# This file is licensed to you under your choice of the GNU Lesser
# General Public License, version 3 or any later version (LGPLv3 or
# later), or the GNU General Public License, version 2 (GPLv2), in all
# cases as published by the Free Software Foundation.
#

GLUSTERFS_LIBEXECDIR = '/usr/lib/x86_64-linux-gnu/glusterfs'
GLUSTERD_WORKDIR = "/var/lib/glusterd"

LOCALSTATEDIR = "/var"
UUID_FILE = "/var/lib/glusterd/glusterd.info"
GLUSTERFS_CONFDIR = "/etc/glusterfs"
GCONF_VERSION = 4.0
